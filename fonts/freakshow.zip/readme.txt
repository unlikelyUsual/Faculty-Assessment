OTF and TTF: Freakshow
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Come one! Come all! Enter at your own risk! Freakshow is a whimsical kaleidoscope of lettering whose likeness is sure to SHOCK the entire family. This unique display font will have you think old newspapers were shredded by a lawnmower and used for a ransom note. Inspiration was years
in the making with some individuals letters and graphics emulated from ads and publications long ago. Different styles such as script, eroded, medieval, and vintage collide with modern looking characters in a haphazardly fashion that will spill your popcorn onto the ground in awe.
Try a combination of uppercase/lowercase to avoid letter repetition and do explore the bonus alternates if your program supports OTF features. Only basic latin and punctuation are included. Other languages, diacritics, accents, and other letters can be added for a fee so email me if interested. 
Make sure your next project or poster is center stage with a ticket to the Freakshow!

WARNING: Do to the complex graphical nature of this font it MAY slow your computer (or any programs that utilize it) down. Please be patient. We are not responsible for any headaches, dizziness, or shortness of breath this may cause! 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: modern, stylish, display, font, typeface, publishing, logo, title, book, cover, magazine, style, brand, branding, fancy, whimsical, carnival, fair, circus, ransom, note, vintage, antique, wood, etching, titular, poster, headline, horror, news
